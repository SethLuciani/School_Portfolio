/*###########################################################################################
File: Contacts.cpp

Author:	Name
Course:	CSCI 182 Introduction to Data Structures
Company: Principia College
Date:	Date

Description:

############################################################################################*/
#include <iostream>		// cin cout
#include <fstream>		// file input and output
#include <string>		// string manipulation
#include "List.h"		// SortedList ADT

using namespace std;

/*~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~*/
#define FILE_NAME "Contacts.csv"

/*~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~*/
int Menu(const int &);

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
int main()
{
	List directory;

//	LoadContacts(directory); /// comment out for release

	while (true)
	{
		switch (Menu(directory.GetLength()))
		{
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
		case 6:
			break;
		case 7:
			break;
		case 0: // Quit
			return 0; // return to the OS
			break;
		default: // invalid selection
			cout << "\nInvalid selection...please choose something from the list\n\n";
			break;
		}
		
		// system pause for user input
		system("pause");

	} // while true

	// we should never get here
	return 0; // return to the OS

} // main

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Function: Menu

Pre:	totalContacts has been provided

Post:	menu has been displayed and user input has been returned to calling function with
		no data validation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
int Menu(const int &totalContacts)
{
	int iSelection;

	system("cls");

	cout << totalContacts << " contact(s) in directory.\n\n"
		<< "1.\tPrint Directory to Screen\n\n"

		<< "2.\tAdd Contact\n"
		<< "3.\tDelete Contact\n\n"

		<< "4.\tLoad Contacts from File\n"
		<< "5.\tSave Contacts to File\n"
		<< "6.\tOpen Contacts File\n\n"

		<< "7.\tSplit Test\n\n"

		<< "0.\tExit\n\n"

		<< "Input: ";

	cin >> iSelection;

	return iSelection;

} // Menu

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/