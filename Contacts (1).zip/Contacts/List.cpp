/*###########################################################################################
File: Name.cpp

Author:		Name
Course:		CSCI 182 Introduction to Data Structures
Company:	Principia College
Date:		Date

Description:

############################################################################################*/
#include "List.h"

struct Node
{
	ItemType data;
	Node *next;

}; // NodeType

   /*##########################################################################################*/
List::List()
{
	listLength = 0;
	head = nullptr;
	Reset();
	tail = nullptr;

} // List default constructor

  /*##########################################################################################*/
List::List(/* in */ const List &inList)
{ // page 749

	Node *from;
	Node *to;

	listLength = inList.GetLength();

	if (inList.head == nullptr)
	{
		head = nullptr;
		return;
	}

	from = inList.head;
	head = new Node;
	head->data = from->data;

	to = head;
	from = from->next;
	while (from != nullptr)
	{
		to->next = new Node;

		to = to->next;
		to->data = from->data;
		from = from->next;
	}

	to->next = nullptr;
	tail = to;

} // SortedList copy constructor

/*##########################################################################################*/
List::List(/* in */ Node *newHead)
{
	head = newHead;
	current = head;
	listLength = 0;

	while (current != nullptr)
	{
		if (current->next == nullptr)
			tail = current;

		current = current->next;

		listLength++;
	}

	Reset();

} // SortedList

/*##########################################################################################*/
List::~List()
{ // page746

	Node *tmp;
	Node *cur = head;

	while (cur != nullptr)
	{
		tmp = cur;
		cur = cur->next;
		delete tmp;
	}

} // ~List

//////////////////////////////////  OPERATION FUNCITONS  /////////////////////////////////////
/*##########################################################################################*/
void List::Insert(/* in */ ItemType item)
{ // page 751
	Node *cur;
	Node *prev;
	Node *newNode = new Node;

	newNode->data = item;
	newNode->next = nullptr;

	if (head == nullptr)
	{
		newNode->next = nullptr;
		head = newNode;
		tail = newNode;
	}
	else
	{
		cur = head;
		prev = nullptr;

		while (cur != nullptr && item > cur->data)
		{
			prev = cur;
			cur = cur->next;
		}

		newNode->next = cur;

		if (prev == nullptr)
			head = newNode;
		else
			prev->next = newNode;

		if (cur == nullptr)
			tail = newNode;
	}

	listLength++;

} // Insert

/*##########################################################################################*/
void List::Delete(/* in */ ItemType item)
{
	Node *prev = nullptr;
	Node *cur = head;

	while (cur != nullptr && !item == cur->data)
	{
		prev = cur;
		cur = cur->next;
	}

	if (cur != nullptr)
	{
		if (cur == head)
			head = cur->next;
		else
			prev->next = cur->next;

		if (cur == tail)
			tail = prev;

		delete cur;
		listLength--;
	}

} // Delete

/*##########################################################################################*/
void List::Reset()
{ current = head; } // Reset

/*##########################################################################################*/
ItemType List::GetNext()
{
	ItemType item = current->data;

	current = current->next;

	return item;

} // GetNext

/*##########################################################################################*/
List List::Split(/* in */ const ItemType &splitItem)
{
	Node *prev = nullptr;	// previous item...used for updating the tail
	Node *cur = head; // current item...start at the head

	while (cur != nullptr && !splitItem == cur->data)
	{
		prev = cur;
		cur = cur->next;
	}

	if (cur != nullptr)
	{
		if (prev == nullptr)
		{
			head = nullptr;
			tail = nullptr;
		}
		else
		{
			tail = prev;
			tail->next = nullptr;
		}

		// create a new list starting at the current item
		List newList(cur);

		listLength -= newList.GetLength();

		// reset the current list
		Reset();

		// return the new list
		return newList;
	}

	// our default is that the item was not found
	return List(); // return an empty list

} // Split

//////////////////////////////////  OBSERVER FUNCITONS  //////////////////////////////////////
/*##########################################################################################*/
int List::GetLength() const
{ return listLength; } // GetLength

/*##########################################################################################*/
bool List::IsEmpty() const
{ return (head == nullptr); } // IsEmpty

/*##########################################################################################*/
bool List::IsFull() const
{ return false; } // IsFull

/*##########################################################################################*/
bool List::IsThere(/* in */ ItemType item) const
{
	Node *cur = head;

	while (cur != nullptr && !item == cur->data)
		cur = cur->next;

	if (cur != nullptr)
		return true;
	else
		return false;

} // IsThere

/*##########################################################################################*/
bool List::HasNext() const
{ return (current != nullptr); } // HasNext

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/