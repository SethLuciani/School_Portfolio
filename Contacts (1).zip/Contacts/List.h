/*###########################################################################################
File: List.h

Author:		Name
Course:		CSCI 182 Introduction to Data Structures
Company:	Principia College
Date:		Date

Description:

############################################################################################*/
#pragma once

#include <string>	// string manipulation

typedef int ItemType;	// data of each node will be == ItemType
struct Node;			// forward declaration of our node (data | next)

class List
{
public:
	/*########################################################################################
	Pre:	none
	Post:	empty list has been created
	########################################################################################*/
	List();

	/*########################################################################################
	Pre:	reference to a SortedList has been provided
	Post:	shallow copy of the list has been created
	########################################################################################*/
	List(/* in */ const List &inList);

	/*########################################################################################
	Pre:	a pointer to a node has been provided
	Post:	a new list has been created starting at the node provided
	########################################################################################*/
	List(/* in */ Node *newHead);

	/*########################################################################################
	Pre:	none
	Post:	all linked list nodes have been deallocated
	########################################################################################*/
	~List();

	//////////////////////////////////  OPERATION FUNCITONS  /////////////////////////////////
	/*########################################################################################
	Pre:	list is not full
	Post:	item is in the list and listLength has been incremented
	########################################################################################*/
	void Insert(/* in */ ItemType item);

	/*########################################################################################
	Pre:	none
	Post:	item is not in the list
	########################################################################################*/
	void Delete(/* in */ ItemType item);

	/*########################################################################################
	Pre:	none
	Post:	current pointer is set to the head of the list
	########################################################################################*/
	void Reset();

	/*########################################################################################
	Pre:	Reset() has been called at prior to first iteration
	Post:	the item at the current has been returned
	########################################################################################*/
	ItemType GetNext();

	/*########################################################################################
	Pre:	none
	Post:	- a new list has been returned starting at the splitItem position
			- current list contains items up to splitItem position
	########################################################################################*/
	List Split(/* in */ const ItemType &splitItem);

	//////////////////////////////////  OBSERVER FUNCITONS  //////////////////////////////////
	/*########################################################################################
	Pre:	none
	Post:	the number of elements in the list has been returned
	########################################################################################*/
	int GetLength() const;
	
	/*########################################################################################
	Pre:	none
	Post:	true has been returned if head == nullptr
	########################################################################################*/
	bool IsEmpty() const;

	/*########################################################################################
	Pre:	none
	Post:	false has been returned
	########################################################################################*/
	bool IsFull() const;

	/*########################################################################################
	Pre:	none
	Post:	true has been returned if item is in the list
	########################################################################################*/
	bool IsThere(/* in */ ItemType item) const;

	/*########################################################################################
	Pre:	none
	Post:	true has been returned if current->next != nullptr
	########################################################################################*/
	bool HasNext() const;

private:
	int listLength;	// number of elements in our list

	Node *head,		// always points to the first element
		 *current,	// used for traversing our list
		 *tail;		// always points to the last element

}; // List

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/