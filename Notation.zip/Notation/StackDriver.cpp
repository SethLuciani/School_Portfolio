/*###########################################################################################
File: StackDriver.cpp

Author:		Seth Luciani
Course:		CSCI 182 Introduction to Data Structures
Company:	Principia College
Date:		3/29/16

Description: A program that changes a fixed equation from an infix to a postfix.

############################################################################################*/
#include <iostream>
#include "Stack.h"
#include <string>
#include <fstream>
#include <iomanip>

using namespace std;

// Struct


/*~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~*/
#define FILE_NAME "variables.txt"

// data type for holding variables
struct Vars
{
	char name;
	float value;
};
/*~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~*/
string IntoPost(const string &);
void StackInit(Stack<Vars>&VarStack);
void PrintVars(Stack<Vars>);
float FindVar(Stack<Vars> varStack, char varName);
float EvalExpression(string, Stack<Vars> varStack);

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
int main()
{
	// Stacks
	Stack<Vars> VarStack;
	Stack<char> charStack;

	// To hold input
	string infix, postfix;

	// To load in all the variables
	StackInit(VarStack);

	// Pause so the reader can see the variables
	system("pause");
	system("cls");

	PrintVars(VarStack);

	// a loop that takes user input as an infix then changes it to postfix
	while (true)
	{
		// prompting the user
		cout << "Enter an infix expression:\n" << 
		"Enter 'E' or 'e' to exit. " << endl;
		cin >> infix;

		// if the user enters e then break out of the loop
		if (infix == "E" || infix == "e")
		{
			break;
		}
		


		// outputting the postfix expression
		cout << "Postfix Expression: " << IntoPost(infix) << endl;

		system("pause");
	}

	return 0;	// return with the status of 0 == Success

} // main

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Function: IntoPost
Pre:	Starts as infix

Post:	Outputs as postfix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

string IntoPost(const string &input)
{
	// Variable Pool
	char curChar;	// To get the current Char
	string postFix = "";		// Our eventual return
	Stack<char> charStack;		// Our Stack
			

	for (int stringIndex = 0; stringIndex < input.length(); stringIndex++)
	{
		// Making the letters all go to upper case
		curChar = toupper(input[stringIndex]);

		// statement used to deal with other symbols
		switch (curChar)
		{
			// 
		case')':
			while (charStack.Top() != '(')
			{
				postFix += charStack.Pop();	// Pop it from the stack
			}
			charStack.Pop();
			break;
		case'(':
			charStack.Push(curChar);	// Push it on to the stack
			break;
		case'*':
		case'/':
			// A while loop checking if * or / is on top of the stack
			while (!charStack.IsEmpty() && strchr("*/", charStack.Top()));
			{
				postFix += charStack.Pop();		// Appending it to the postfix
			}
			charStack.Push(curChar);
			break;

		case'+':
		case'-':
			// A while loop checking if + or - is on top of the stack
			while (!charStack.IsEmpty() && strchr("*/+-", charStack.Top()));
			{
				postFix += charStack.Pop();		// Appending it to the post fix

				charStack.Push(curChar);
				break;

		default:
			postFix += curChar;				// For the letter in the equation
			}

		}

	}
		while (!charStack.IsEmpty())
		{
			postFix += charStack.Pop();				// printing out the rest of the operators
		}

		return postFix;
	
}// IntoPost

 /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Function: StackInit

 Pre: A .txt file has been provided

 Post: The variable from the .txt file have been loaded into a variable stack.
 This function is also printing them off and displaying them to the user.
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

void StackInit(Stack<Vars>&VarStack)
{
	// opening the file
	fstream fin;
	fin.open(FILE_NAME);
	cout << "File variables.txt was opened. " << endl;

	// loop reading in the info from the file
	while (!fin.eof())
	{
		Vars temp;
		char junk;
		fin >> temp.name >> junk >> temp.value;

		temp.name = toupper(temp.name);
		
		// formatting 
		right;
		cout << setw(15) << "Pushed " << "[" << temp.name << " " << temp.value << "]" << endl;
		
		// Pushing temp on to the stack
		VarStack.Push(temp);
	}

	// closing the file
	fin.close();
	cout << FILE_NAME << " has been closed." << endl;
}// StackInit

 /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Function: PrintVars

 Pre: stack initialized with values

 Post: Values from stack printed to screen
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

void PrintVars(Stack<Vars> varStack)
{
	cout << "Variables from the Stack: \n\n";

	// temporary variable
	Vars temp;

	// Going through until the stack is empty
	while (!varStack.IsEmpty())
	{
		// popping the variables
		temp = varStack.Pop();

		// outputting the variables
		cout << temp.name << " " << temp.value << "\t";

		// formatting for a second variable to be shown on the same line
		if (!varStack.IsEmpty())
		{
			temp = varStack.Pop();

			cout << temp.name << " " << temp.value << endl;
		}
	}

}// PrintVars

 /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Function: FindVar

 Pre: stack of variables that is populated, and a char given by the user

 Post: The char was found
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

float FindVar(Stack<Vars> varStack, char varName)
{
	Vars temp;


	while (!varStack.IsEmpty())
	{
		// popping the variables
		temp = varStack.Pop();

		// finding the value
		if (varName == temp.name)
		{
			return temp.value;
		}
	}

	return FLT_MAX;

}// FindVar

 /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Function: EvalExpression

 Pre: We have a filled postfix variable and a var stack that is filled

 Post: The expression is evaluated
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

float EvalExpression(string postFix, Stack<Vars> &varStack)
{
	char curChar;
	float hold1;
	float hold2;
	Stack<float> floatStack;

	for (int stringIndex = 0; stringIndex < postFix.length(); stringIndex++)
	{
		switch (curChar)
		{
		// Switch statement to evaluate the postfix expression
		// division
		case '/':
			// popping two items
			hold1 = floatStack.Pop();
			hold2 = floatStack.Pop();

			// the math
			floatStack.Push(hold2 / hold1);
		case '*':
			hold1 = floatStack.Pop();
			hold2 = floatStack.Pop();

			floatStack.Push(hold1 * hold2);
		case '+':
			hold1 = floatStack.Pop();
			hold2 = floatStack.Pop();

			floatStack.Push(hold1 + hold2);
		case '-':
			hold1 = floatStack.Pop();
			hold2 = floatStack.Pop();

			floatStack.Push(hold2 - hold1);
		// if the it is a character or number
		default: 
			floatStack.Push(FindVar(varStack, curChar));
		}
	}

	// returning the evaluated expression
	return floatStack.Pop();

}// EvalExpression
/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/