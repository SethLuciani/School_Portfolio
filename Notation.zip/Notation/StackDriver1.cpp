/*###########################################################################################
File: StackDriver.cpp

Author:		Seth Luciani
Course:		CSCI 182 Introduction to Data Structures
Company:	Principia College
Date:		3/29/16

Description:

############################################################################################*/
#include <iostream>
#include "Stack.h"
#include <string>


using namespace std;

/*~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~*/

/*~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~*/
string IntoPost(string);

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
int main()
{
	//Stack<int> intStack;
	Stack<char> charStack;

	/*intStack.Push(5);
	intStack.Push(4);
	intStack.Push(1);

	printf("Int Stack Size: %d\n", intStack.Size());

	charStack.Push('A');
	charStack.Push('z');

	printf("Char Stack Size: %d\n", charStack.Size());*/

	string kevin;

	kevin = "A*B/C";

	cout << "Infix: " << kevin << endl;

	cout << "Postfix: " << IntoPost(kevin) << endl;

	system("pause"); // pause and wait for user input

	return 0;	// return with the status of 0 == Success

} // main

  /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  Function: IntoPost

  Pre:	Starts as infix

  Post:	Outputs as postfix
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

string IntoPost(string input)
{
	char curChar;
	Stack<char> charStack;
	string postFix = "";

	for (int i = 0; i < input.length(); i++)
	{
		curChar = toupper(input[i]);

		switch (curChar)
		{

		case')':
			while (charStack.Top() != '(')
			{
				charStack.Pop();
			}
			break;
		case'(':
			charStack.Push(curChar);
			break;
		case'*':
		case'/':
			while (!charStack.IsEmpty() && charStack.Top() == '*' || charStack.Top() == '/')
			{
				postFix += charStack.Pop();
			}
			charStack.Push(curChar);
			break;

		case'+':
		case'-':
			while (!charStack.IsEmpty() && charStack.Top() == '*' || charStack.Top() == '/'
				|| charStack.Top() == '+' || charStack.Top() == '-')
			{
				postFix += charStack.Pop();
			}
			charStack.Push(curChar);
			break;

		default:
			{
			postFix += curChar;
			}
		}

	}

	while (!charStack.IsEmpty())
	{
		postFix += charStack.Pop();
	}

	return postFix;

}// IntoPost

 /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/