/*###########################################################################################
File: DiskMaker.cpp

Author:		Seth Luciani
Company:	Principia College
Course:		CSCI 182 - Introduction to Data Structures
Professor:	John Broere
Date:		1/28/16

Description: This program takes in a input file that contains song lengths in seconds. It then
outputs these songs, separated into minutes and seconds, to an output file. In this output file the 
songs are numbered as tracks, they are also shown in minutes and seconds, and the tracks are added up 
for the length of the entire disk.

Sources: Programming and Problem Solving with C++, CPlusPlus.com, Google.com, and TA's

############################################################################################*/

/*~~~~~ INCLUDES ~~~~~~~~ INCLUDES ~~~~~~~~ INCLUDES ~~~~~~~~ INCLUDES ~~~~~~~~ INCLUDES ~~~*/
#include <iostream>										// to recieve input and use outputs
#include <fstream>										// to use ifstream, ofstream, and fstream
#include <string>										// to use strings
#include <iomanip>										// formatting

using namespace std;

/*~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~*/
#define INPUT_FILE "songs.txt"							// songs.txt is the input file where we get the information
#define OUTPUT_FILE "disk_info.txt"						// disk_info.txt is the output file where the info is sent

/*~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~*/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Struct:	Time
Description:	A struct used to keep track of time.  Struct has one data member named
	dSeconds which will keep track of the time of the struct in seconds.  There are functions
	that allow the user of the struct to set and get different versions of the time as well
	as compare one struct of time with another.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
struct Time
{
	double dSeconds; // variable to keep track of time for this instance

	Time() { dSeconds = 0.0; } // default constructor
	Time(double dSec) { dSeconds = dSec; } // constructor with init
	Time(int hours, int minutes, double newSeconds) // constructor with full init
	{
		dSeconds = (double)(hours * 3600 + minutes * 60) + newSeconds;
	}

	// reset the value of seconds
	void setSeconds(double newSeconds) { dSeconds = newSeconds; }

	double GetTime() { return dSeconds; } // Return elapsed time
	int GetMinutes() { return (int)dSeconds / 60; } // Compute minutes
	double GetSec() { return fmod(dSeconds, 60.0); } // Seconds after minutes taken out

	// add the provided time to this instance
	Time plus(Time otherTime){
		return Time(dSeconds + otherTime.GetTime());
	}

	// subtract the provided time from this instance
	Time minus(Time otherTime){ return Time(dSeconds - otherTime.GetTime()); } 

	// compare the provided time to this instance
	int CompareTo(Time otherTime) {

		int roundSeconds = (int)(dSeconds * 100.0 + 0.5);			// Round up seconds * 100
		int roundOther = (int)(otherTime.GetTime() * 100.0 + 0.5);	// Round up other * 100
		if (roundSeconds > roundOther)								// If this object > other
			return 1;												//   then positive result
		else if (roundSeconds < roundOther)							// If this object < other
			return -1;												//   then negative result
		else														// If this object = other
			return 0;												//   then zero result
	}
};

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
int main()
{
	/* ********************************************************************************************
	* File Preparation
	*
	*/
	
	// prepare input file for reading
	fstream fin(INPUT_FILE, fstream::in);
	cout << INPUT_FILE << " has been opened to read.\n";

	// prepare output file for writing
	fstream fout(OUTPUT_FILE, fstream::out);
	cout << OUTPUT_FILE << " has been opened to write.\n";

	/* ********************************************************************************************
	* Main Program
	*
	*/

	// variable pool
	Time SongTime = Time();
	Time TotalTime = Time();
	Time TimeRemaining = Time(4800.0);
	char inBuffer[10];
	double songTimeArray[1000];
	string temp;
	int trackNumber = 0;
	int songSkippedCounter = 0;
	

	while (!fin.eof())									// recieving the ints from the file
	{
		getline(fin, temp);			// Geting the next line from the file
		songTimeArray[trackNumber] = stod(temp);			// Parsing string for an int, also storing them an array
		trackNumber++;										// Adding how many times we pass through the array
	}

	int counter = 0;
	int songCounter = 0;

	fout << "Song              Song Time           Total Time    " << endl;						// Formatting for output file
	fout << "Number         Minutes   Seconds   Minutes   Seconds " << endl;
	fout << "_______        _______   _______   _______   _______  " << endl;
	
	while (songCounter < trackNumber)					// while loop that takes values from the songTimeArray array and outputs them to the output file	
	{
		SongTime.setSeconds(songTimeArray[songCounter]);
		if(TimeRemaining.CompareTo(SongTime) == 1 || TimeRemaining.CompareTo(SongTime) == 0) // It will only choose a song if the time remaining is more than 0
		{
			TotalTime = TotalTime.plus(SongTime);
			// The math a output to the file
			fout << left << setw(15) << counter + 1 << setw(10) << SongTime.GetMinutes() << setw(10) << SongTime.GetSec() << setw(10) << TotalTime.GetMinutes() << setw(10) << TotalTime.GetSec() << endl;
			TimeRemaining = TimeRemaining.minus(SongTime);			// Each new song will be subtracted from the song time which is 4800 seconds or 80 mins
			counter++;
		}    
		else
		{
			songSkippedCounter++;							// Counting the number of songs skipped
		}

		songCounter++;
	}

	fout << "_______        _______   _______   _______   _______  " << endl;

	fout << " " << endl;

	if (songSkippedCounter > 0)											// counting the amount of times we skip a song
	{
		fout << "Disk became full before end of input file. " << endl;					// Output for skipped songs
		fout << " " << endl;
		fout << "Skipped " << songSkippedCounter << " song(s) due to time before disk became full. " << endl;
	}
	
	fout << " " << endl;
	fout << "There are " << TimeRemaining.GetMinutes() << " minutes and " << TimeRemaining.GetSec() << " seconds of space left on the 80 minute CD." << endl;
	
	fin.getline(inBuffer, 10);

	while (!fin.fail())
	{
		fout << atof(inBuffer) << endl;
		
		fin.getline(inBuffer, 10);
	
	} // main while loop

	/* ********************************************************************************************
	* File Clean-up
	*
	*/

	// close files and report to user
	fin.close();
	cout << INPUT_FILE << " has been closed\n";
	fout.close();
	cout << OUTPUT_FILE << " has been closed\n";

	system("pause"); // system call to wait for user input

	return 0;
} // main

  /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/