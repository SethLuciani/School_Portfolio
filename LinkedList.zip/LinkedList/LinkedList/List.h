/*###########################################################################################
File: List.h

Author:   Seth Luciani
Company:	Principia College
Course:		CSCI 182 - Introduction to Data Structures
Professor:	John Broere
Date:		March 7 2016

Description: This program creates a Linked list and then converts it to a split list.

Sources: Teacher, TA's(Nick Flanders and Joey Sanders), and the Internet(mainly cplusplus.com)

############################################################################################*/
#pragma once

typedef int ItemType;		// Type of each component
struct NodeType;			// forward declaration

class List
{
	int x;

public:
	int nList(NodeType *newHead);

	List();
	// constructor
	// Post: empty list has been created

	~List();

	/*############################################################################################################
	Function: Insert

	Pre: List is not full and item is not in the list	

	Post: Item is in the list and length has been incremented
	############################################################################################################*/
	void Insert(ItemType item);

	/*############################################################################################################
	Function: Delete

	Pre: None

	Post: Item is not in the list
	############################################################################################################*/
	void Delete(ItemType item);

	/*############################################################################################################
	Function: Reset

	Post:	current pointer is set to the head of the list
	############################################################################################################*/
	void Reset();

	/*############################################################################################################
	Function: GetNextItem

	Pre: Reset has been called if this isn't the first iteration

	Post: Returns item at current position
	############################################################################################################*/
	ItemType GetNextItem();
	
	/*############################################################################################################
	Function: GetLength

	Post: Returns length of the list
	############################################################################################################*/
	int GetLength() const;
	
	/*############################################################################################################
	Function: IsEmpty

	Pre: None

	Post: Returns true if list is empty; false otherwise
	############################################################################################################*/
	bool IsEmpty() const;
	
	/*############################################################################################################
	Function: IsFull

	Pre: None

	Post: Returns true if list is full; false otherwise
	############################################################################################################*/
	bool IsFull() const;
	
	/*############################################################################################################
	Function: IsThere

	Pre: None

	Post: Returns true if item is in the list
	############################################################################################################*/
	bool IsThere(ItemType item) const;
	
	/*############################################################################################################
	Function: HasNext

	Pre: None

	Post: Returns true if there is another item to be returned
	############################################################################################################*/
	bool HasNext() const;
	
	/*############################################################################################################
	Function: Split

	Pre: None

	Post: Returns a split list
	############################################################################################################*/
	List* Split(ItemType item);

private:
	int listLength; // number of elements in our list

	NodeType *head,			// always points to the first element
		     *current,		// used for traversing our list
		     *tail;			// always points to the last element
}; // List
/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/