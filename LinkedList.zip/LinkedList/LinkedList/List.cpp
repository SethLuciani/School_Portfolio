/*###########################################################################################
File: List.cpp

Author:   Seth Luciani
Company:	Principia College
Course:		CSCI 182 - Introduction to Data Structures
Professor:	John Broere
Date:		March 7 2016

Description: This program creates a Linked list and then converts it to a split list.

Sources: Teacher, TA's(Nick Flanders and Joey Sanders), and the Internet(mainly cplusplus.com)

############################################################################################*/

#include "List.h"
#include <iostream>
#include <cstddef>

struct NodeType
{
	ItemType data;
	NodeType *next;
}; // NodeType
   
   /*##########################################################################################################*/

List::List()
{
	listLength = 0;
	head = nullptr;
	Reset();
	tail = nullptr;

} // List
  
  /*##########################################################################################################*/

List::~List()
{    

} // ~List

List::nList(NodeType *newHead, ItemType item)
{
	NodeType *currPtr;			// Moving Pointer
	NodeType *prevPtr;			// Trailing Pointer
	NodeType *newNodePtr;		// Pointer to new node

	head = newHead;
	currPtr = head;
	while (currPtr != NULL && currPtr->data != item)
		currPtr = currPtr->next;
	if (currPtr != NULL)
		return true;
	else
		return false;

}
  
  /*##########################################################################################################*/

void List::Insert(ItemType item)
// Post: New Node containing item is in its proper place and 
//       component members of list nodes are in ascending
{
	NodeType *currPtr;			// Moving Pointer
	NodeType *prevPtr;			// Trailing Pointer
	NodeType *newNodePtr;		// Pointer to new node

	newNodePtr = new NodeType();
	newNodePtr->data = item;

	if (head == nullptr)		// Empty List
	{
		newNodePtr->next = nullptr;
		head = newNodePtr;
		tail = newNodePtr;
	}
	else
	{ // Find previous insertion point
		currPtr = head;
		prevPtr = nullptr;
		while (currPtr != nullptr && currPtr->data < item)
		{
			prevPtr = currPtr;
			currPtr = currPtr->next;
		}

		// Insert new node
		newNodePtr->next = currPtr;
		if (prevPtr == NULL)				// Insert as first?
			head = newNodePtr;
		else
			prevPtr->next = newNodePtr;
		if (currPtr == NULL)				// Insert as last?
			tail = newNodePtr;
	}
	current = head;
	listLength++;
} // Insert

void List::Delete(ItemType item)
{
	NodeType *prevPtr = NULL;	// Trailing pointer
	NodeType *currPtr = head;
	while (currPtr != NULL && currPtr->data != item)
	{
		prevPtr = currPtr;				// Sets prevPtr to what currPtr is set to
		currPtr = currPtr->next;		// currPtr now points to where the pointer in next points to(the next node's data compoment)
	}
	if (currPtr != NULL)
	{	// item is found
		if (currPtr == head)
			head = currPtr->next;
		else
			prevPtr->next = currPtr->next;
		if (currPtr == tail)
			tail = prevPtr;
		delete currPtr;
		listLength--;
	}


} // Delete

void List::Reset()
{
	current = head;
} // reset
  
  /*##########################################################################################################*/

int List::GetLength() const
{ // Returning listLength
	return listLength;
} // GetLength

  /*##########################################################################################################*/

bool List::IsEmpty() const
{
	return (head == NULL);
} // IsEmpty
bool List::IsFull() const
{
	return false;
} // IsFull
bool List::IsThere(ItemType item) const
{ // Checking if the item is even in the list
	NodeType *currPtr = head;

	while (currPtr != NULL && currPtr->data != item)
		currPtr = currPtr->next;
	if (currPtr != NULL)
		return true;
	else
		return false;
} // IsThere
bool List::HasNext() const
{
	return (current != NULL);
} // HasNext
List* List::Split(ItemType item)
{
	// Variable Pool
	List *newList = new List();
	NodeType *prevPtr = NULL;
	NodeType *currPtr = head;
	int count = 1;

	if (IsThere(item))
	{ // Checking if the item to split on is in the list
		while (currPtr != NULL && currPtr->data != item)
		{ // Moving through the list looking for item
			prevPtr = currPtr;
			currPtr = currPtr->next;
			count++;
		}
		// Resetting the pointers to accomodate the second list being created
		newList->head = currPtr;
		newList->tail = tail;
		tail = prevPtr;
		tail->next = NULL;

		// Finding the length of list
		listLength = count -1;
		newList->listLength = listLength - count + 1;
		
	}

	return newList;
} // Split
ItemType List::GetNextItem()
{ // Returning the next item
	ItemType item;
	item = current->data;
	current = current->next;
	return item;

} // GetNextItem

