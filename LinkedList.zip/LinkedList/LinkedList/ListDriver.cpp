/*###########################################################################################
File: ListDriver.cpp

Author:   Seth Luciani
Company:	Principia College
Course:		CSCI 182 - Introduction to Data Structures
Professor:	John Broere
Date:		March 7 2016

Description: This program creates a Linked list and then converts it to a split list.

Sources: Teacher, TA's(Nick Flanders and Joey Sanders), and the Internet(mainly cplusplus.com)

############################################################################################*/
#include <iostream>
#include "List.h"
#include <fstream>
#include <string>

using namespace std;

#define Input "Input.txt"

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N  **  M A I N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
int main()
{
	List myList;
	ifstream inData;
	ItemType item;
	string s;
	List *List2;

	// Open file
	inData.open("Input.txt");

	while (!inData.eof())
	{ // Getting the elements from the text file and turning them from strings to ints
		getline(inData, s);
		item = stoi(s);
		// Inserting the elements into the list
		myList.Insert(item);
	
	}
	while (myList.HasNext())
	{ // Displaying the full list
		cout << myList.GetNextItem() << ',';
	}
	cout << endl;
	List2 = myList.Split(5);
	// Splitting the list into two parts
	while (myList.HasNext())
	{ // Display the first half of the list
		cout << myList.GetNextItem() << ',';
	}
	while (List2.HasNext())
	{ // Display the second half of the list
		cout << List2.GetNextItem() << ',';
	}

	cout << myList;
	cout << List2;

	printf("myList length = %d\n", myList.GetLength());

	inData.close();

	system("Pause");

	return 0;
} // main
  /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F  **  E  O  F
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/