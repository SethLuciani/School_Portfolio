#include <iostream>		// console input/output
#include <random>		// random numbers
#include <time.h>		// used to seed random

using namespace std;

#define ARRAY_MAX	10

typedef int ItemType;

// function prototypes
void Menu();
void ArrayInit(ItemType[]);
void PrintArray(ItemType[]);
void SelectionSortTest();
void SelectionSort(ItemType[]);
void BubbleSortTest();
void BubbleSort(ItemType[]);
void InsertionSortTest();
void InsertionSort(ItemType[]);

int main()
{
	// seed the random number
	srand(time(NULL));

	SelectionSortTest();
	system("pause");
	system("cls");

	BubbleSortTest();
	system("pause");
	system("cls");

	InsertionSortTest();
	system("pause");
	system("cls");

	return 0;

} // main

void ArrayInit(ItemType data[])
{
	// Iterate through the entire array and initialize with random numbers
	for (int iIndex = 0; iIndex < ARRAY_MAX; iIndex++)
		data[iIndex] = rand() % 100;
}

void PrintArray(ItemType data[])
{
	// Iterate through the entire array and print the value
	for (int iIndex = 0; iIndex < ARRAY_MAX; iIndex++)
		cout << data[iIndex] << " ";

	// after printing the array insert a line break
	cout << "\n";
}

void SelectionSortTest()
{
	ItemType data[ARRAY_MAX];

	cout << "Selection Sort Test:\n\n";

	ArrayInit(data);
	PrintArray(data);
	SelectionSort(data);
	PrintArray(data);

}

/*

*/
void SelectionSort(ItemType data[])
{
	// variable pool
	int position, low;

	// starts at 0 and reduces the rest of the list we are looking at
	// increases the sorted list to the left of the array
	for (int outerIndex = 0; outerIndex < ARRAY_MAX; outerIndex++)
	{
		// init the current low and position
		low = data[outerIndex];
		position = outerIndex;

		// find the lowest element in the remaining part of the array
		for (int innerIndex = outerIndex + 1; innerIndex < ARRAY_MAX; innerIndex++)
		{

			if (data[innerIndex] < low)
			{ // found a new low element
				low = data[innerIndex];
				position = innerIndex;
			}
		} // inner for

		if (position != outerIndex)
		{ // the current position in the array was not the lowest...swap them
			data[position] = data[outerIndex];
			data[outerIndex] = low;
		}

	} // outer for

} // SelectionSort

void BubbleSortTest()
{
	ItemType data[ARRAY_MAX];

	cout << "Bubble Sort Test:\n\n";

	ArrayInit(data);
	PrintArray(data);
	BubbleSort(data);
	PrintArray(data);

} // BubbleSortTest

void BubbleSort(ItemType data[])
{


} // BubbleSort

void InsertionSortTest()
{
	ItemType data[ARRAY_MAX];

	cout << "Insertionn Sort Test:\n\n";

	ArrayInit(data);
	PrintArray(data);
	InsertionSort(data);
	PrintArray(data);

} // InsertionSortTest

void InsertionSort(ItemType data[])
{

} // InsertionSort