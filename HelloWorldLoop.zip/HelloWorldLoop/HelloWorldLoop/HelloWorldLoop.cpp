/*##########################################################################
Program: HelloWorldLoop.cpp

Author:		Seth Luciani
Company:	Principia College
Course:		CSCI 182: Intro to Data Structures
Date:		January 22,2016

Description:
This program allows the user to repeat the same question in a loop. It repeats until they enter 'N'.
This program utilizes a print function and a do while loop.

##########################################################################*/

#include <iostream>
using namespace std;

int main()
{
	// Declaring Variables
	char cRepeat; // Control variable
	int iCount = 1; // loop counter variable

	do
	{
		printf("Hello World! %d Pass\n ", iCount); // outputting to user
		cout << "Repeat Program? (y or n) "; // output to user
		cin >> cRepeat;						// recieving input
		cRepeat = toupper(cRepeat);

		while (cRepeat != 'Y' && cRepeat != 'N')	// If the user types something other than Y or N
		{
			cout << "Aren't you listening? ";	// Questioning their decision
			cout << "Please answer with y or n: "; // Help them make the right choice
			cin >> cRepeat;							// Retake their input
			cRepeat = toupper(cRepeat);
		}
		iCount = iCount + 1;
	} while (cRepeat == 'Y');						// If its Y then the loop will end

	cout << "Thanks for playing! " << endl;					// Closing Message

	system("pause");								// To keep it open
	return 0;
} // main