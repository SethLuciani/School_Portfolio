///////////////////////////////////////////////////////////////////////////////////////////////////////
// Specification File: AccessPoint.cpp
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/23/2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#include "AccessPoint.h"

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
AccessPoint::AccessPoint()
{
	iAP_ID = -999;
	status = NO_STATE;
	turnedOn = NO_MONTH;

} // AccessPoint

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
AccessPoint::~AccessPoint()
{
	// nothing needed here

} // ~AcessPoint

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
bool AccessPoint::Init(/* in */ int iNum, /* in */ months month)
{
	if (iNum < 0 || iNum > 3)
		return false; // AP number is not valid

	// AP number was valid...we need to set it now
	iAP_ID = iNum;

	status = OFF;

	// return the status of turning on the AP with the month given
	return TurnOn(month);

} // Init

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
bool AccessPoint::TurnOn(/* in */ months month)
{
	bool bSuccess; // used to determin if the operation was successful

	if (iAP_ID < 1) // access point has not been initilized
		bSuccess = false;

	switch (status)
	{
	case ON: // The access point was already on
		bSuccess = false;
		break;
	default:
		switch (month)
		{
		case NO_MONTH: // no month specified...we can't turn the AP on without a month
			bSuccess = false;
			break;
		default: // turn the AP on and set the month
			status = ON;
			turnedOn = month;
			bSuccess = true;
			break;
		} // switch
		break;
	} // switch

	return bSuccess;

} // TurnOn

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
bool AccessPoint::TurnOff()
{
	status = OFF;
	turnedOn = NO_MONTH;

	return true;

} // TurnOff

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
states AccessPoint::Status()
{
	return status;

} // Status

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
std::string AccessPoint::StatusToString()
{
	std::string sStatus;

	switch (status)
	{
	case ON:
		sStatus = "On";
		break;
	case OFF:
		sStatus = "Off";
		break;
	default:
		sStatus = "N/A";
		break;
	}

	return sStatus;
}

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
months AccessPoint::TurnedOn()
{
	return turnedOn;

} // TurnedOn

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
std::string AccessPoint::TurnedOnToString()
{
	std::string sMonth;

	switch (turnedOn)
	{
	case JANUARY:
		sMonth = "January";
		break;
	case FEBRUARY:
		sMonth = "February";
		break;
	case MARCH:
		sMonth = "March";
		break;
	case APRIL:
		sMonth = "April";
		break;
	case MAY:
		sMonth = "May";
		break;
	case JUNE:
		sMonth = "June";
		break;
	case JULY:
		sMonth = "July";
		break;
	case AUGUST:
		sMonth = "August";
		break;
	case SEPTEMBER:
		sMonth = "September";
		break;
	case OCTOBER:
		sMonth = "October";
		break;
	case NOBEMBER:
		sMonth = "November";
		break;
	case DECEMBER:
		sMonth = "December";
		break;
	default:
		sMonth = "N/A";
		break;
	}

	return sMonth;

} // TurnedOnToString

  /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
int AccessPoint::GetAP_ID()
{
	return iAP_ID;

} // GetAP_ID