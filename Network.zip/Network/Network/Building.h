///////////////////////////////////////////////////////////////////////////////////////////////////////
// Specification File: Building.h
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/23/2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma once

#include <string>
#include "Floor.h";

const int FLOORS_MIN = 10;
const int FLOORS_MAX = 100;

class Building
{
public:
	////////////////////////////////////////  CONSTRUCTORS  ///////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: Building
	Pre:	None
	Post:
	*/
	Building();

	////////////////////////////////////////  DESTRUCTORS  ////////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: ~Building
	Pre:	None
	Post:
	*/
	~Building();

	////////////////////////////////////////  OPERATION FUNCITONS  ////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	Init
	Pre:
	Post:
	*/
	void Init(/* in */ int iNum, /* in */ std::string sNewName);

	////////////////////////////////////////  OBSERVER FUNCITONS  /////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	GetName
	Pre:
	Post:
	*/
	int GetNumber();

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	GetName
	Pre:
	Post:
	*/
	std::string GetName();

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	GetFloorCount
	Pre:
	Post:
	*/
	int GetFloorCount();

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	GetFloor
	Pre:
	Post:
	*/
	Floor GetFloor(int iNum);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	TurnOff
	Pre:
	Post:
	*/
	bool TurnOff(/* in */ int iFloor, /* in */ int iRoom, /* in */ int iAP);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	TurnOn
	Pre:
	Post:
	*/
	bool TurnOn(/* in */ int iFloor, /* in */ int iRoom, /* in */ int iAP, /* in */ months month);

private:
	// get instnace of Randomizer used for generating random numbers
	Randomizer rRand = Randomizer::Instance();

	// each building has a unique number
	int iBuildingNumber;

	// each building has a name
	std::string sName;

	// each building has a specific number of floors ranging from 10-100
	int iNumberOfFloors;

	// used to represent the floors in each building instance
	Floor *floors;

}; // Building