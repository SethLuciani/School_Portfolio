///////////////////////////////////////////////////////////////////////////////////////////////////////
// Specification File: Building.cpp
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/23/2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#include "Building.h"

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
Building::Building()
{
	// building has been created, but not initialized
	iBuildingNumber = -999;
	sName = "None";

	// get random number of floors for each instnace of bulding
	iNumberOfFloors = rRand.InRange(FLOORS_MIN, FLOORS_MAX);

	// allocate memory for the specific number of floors for each instance
	floors = new Floor[iNumberOfFloors];

	// initialize all the floors in the building instance
	for (int iCounter = 0; iCounter < iNumberOfFloors; iCounter++)
		floors[iCounter].Init(iCounter + 1);

} // Building

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
Building::~Building()
{
	// Nothing needed here

} // ~Building

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
void Building::Init(/* in */ int iNum, /* in */ std::string sNewName)
{
	iBuildingNumber = iNum;
	sName = sNewName;

} // Init

  /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
int Building::GetNumber()
{
	return iBuildingNumber;

} // GetNumber

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
std::string Building::GetName()
{
	return sName;

} // GetName

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
int Building::GetFloorCount()
{
	return iNumberOfFloors;

} // GetFloorCount

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
Floor Building::GetFloor(int iNum)
{
	return floors[iNum];

} // GetFloor

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
bool Building::TurnOff(/* in */ int iFloor, /* in */ int iRoom, /* in */ int iAP)
{
	if (iFloor <= 0 || iFloor > iNumberOfFloors)
		return false;
	else
		return floors[iFloor - 1].TurnOff(iRoom, iAP);

} // TurnOff

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
bool Building::TurnOn(/* in */ int iFloor, /* in */ int iRoom, /* in */ int iAP, /* in */ months month)
{
	if (iFloor <= 0 || iFloor > iNumberOfFloors)
		return false;
	else
		return floors[iFloor - 1].TurnOn(iRoom, iAP, month);

} // TurnOn