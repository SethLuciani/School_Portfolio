///////////////////////////////////////////////////////////////////////////////////////////////////////
// Specification File: Floor.cpp
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/23/2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#include "Floor.h"

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
Floor::Floor()
{
	// room has been created, but not initialized
	iFloorNumber = -999;

	// we want to insist on 40% of the floors having between ROOMS_MIN and ROOMS_MAX/2 rooms
	if ((rand() % 100) < 40)
		iNumberOfRooms = rRand.InRange(ROOMS_MIN, ROOMS_MAX/2);
	else // 70% of the floors have between ROOMS_MAX/2 and ROOMS_MAX rooms
		iNumberOfRooms = rRand.InRange(ROOMS_MAX/2, ROOMS_MAX);

	// allocate memory for the specific number of rooms for each instance
	rooms = new Room[iNumberOfRooms];

	// initialize all the access points in the room instance
	for (int iCounter = 0; iCounter < iNumberOfRooms; iCounter++)
		rooms[iCounter].Init(iCounter + 1);

} // Floor

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
Floor::~Floor()
{
	// Nothing needed here

} // ~Floor

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
void Floor::Init(/* in */ int iNum)
{
	iFloorNumber = iNum;

} // Init

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
int Floor::GetRoomCount()
{
	return iNumberOfRooms;

} // GetRoomCount

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
Room Floor::GetRoom(/* in */ int iNum)
{
	return rooms[iNum];

} // GetRoom

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
bool Floor::TurnOff(/* in */ int iRoom, /* in */ int iAP)
{
	if (iRoom <= 0 || iRoom > iNumberOfRooms)
		return false;
	else
		return rooms[iRoom - 1].TurnOff(iAP);

} // TurnOff

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
bool Floor::TurnOn(/* in */ int iRoom, /* in */ int iAP, /* in */ months month)
{
	if (iRoom <= 0 || iRoom > iNumberOfRooms)
		return false;
	else
		return rooms[iRoom - 1].TurnOn(iAP, month);

} // TurnOff