///////////////////////////////////////////////////////////////////////////////////////////////////////
// Specification File: Floor.h
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/23/2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma once

#include "Room.h";

const int ROOMS_MIN = 15;
const int ROOMS_MAX = 30;

class Floor
{
public:
	////////////////////////////////////////  CONSTRUCTORS  ///////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: Floor
	Pre:	None
	Post:
	*/
	Floor();

	////////////////////////////////////////  DESTRUCTORS  ////////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: ~Floor
	Pre:	None
	Post:
	*/
	~Floor();

	////////////////////////////////////////  OPERATION FUNCITONS  ////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	Init
	Pre:
	Post:
	*/
	void Init(/* in */ int iNum);

	////////////////////////////////////////  OBSERVER FUNCITONS  /////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	GetRoomCount
	Pre:
	Post:
	*/
	int GetRoomCount();

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	GetRoom
	Pre:
	Post:
	*/
	Room GetRoom(/* in */ int iNum);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	TurnOff
	Pre:
	Post:
	*/
	bool TurnOff(/* in */ int iRoom, /* in */ int iAP);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	TurnOn
	Pre:
	Post:
	*/
	bool TurnOn(/* in */ int iRoom, /* in */ int iAP, /* in */ months month);

private:
	// get instnace of Randomizer used for generating random numbers
	Randomizer rRand = Randomizer::Instance();

	// each floor has a unique number
	int iFloorNumber;

	// each instance of floor has a number of rooms ranging from 15-30
	int iNumberOfRooms;

	// used to represent the rooms in each floor instance
	Room *rooms;

}; // Floor