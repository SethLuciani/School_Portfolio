///////////////////////////////////////////////////////////////////////////////////////////////////////
// Specification File: Room.cpp
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/23/2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#include "Room.h"

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
Room::Room()
{
	// room has been created, but not initialized
	iRoomNumber = -999;

	// get random number of APs for each instnace of room
	iNumberOfAPs = rRand.InRange(AP_MIN, AP_MAX);

	// allocate memory for the specific number of APs for each instance
	accessPoints = new AccessPoint[iNumberOfAPs];

	int iRandNumber;

	// initialize all the access points in the room instance
	for (int iCounter = 0; iCounter < iNumberOfAPs; iCounter++)
	{
		// we want to insist on 40% of the APs being off
		if ((rand() % 100) < 40)
			iRandNumber = 0;
		else // 60% of the APs can turned on between Jan and Dec
			iRandNumber = rRand.InRange(1, 12);

		// randomly set accesspoints on or off with valid months
		accessPoints[iCounter].Init(iCounter + 1, static_cast<months>(iRandNumber));
	}

} // Room

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
Room::~Room()
{
	// nothing needed here

}// ~Room

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
void Room::Init(/* in */ int iNum)
{
	iRoomNumber = iNum;

} // Init

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
int Room::GetAPCount()
{
	return iNumberOfAPs;

} // GetRoomNumber

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
AccessPoint Room::GetAP(/* in */ int iNum)
{
	return accessPoints[iNum];

} // GetAP

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
bool Room::TurnOff(/* in */ int iAP)
{
	if (iAP <= 0 || iAP > iNumberOfAPs)
		return false;
	else
		return accessPoints[iAP - 1].TurnOff();

} // GetAP

  /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
bool Room::TurnOn(/* in */ int iAP, /* in */ months month)
{
	if (iAP <= 0 || iAP > iNumberOfAPs)
		return false;
	else
		return accessPoints[iAP - 1].TurnOn(month);

} // GetAP