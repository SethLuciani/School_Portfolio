//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Main Program File: NetworkAPs.cpp
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/25/2015
//
// Description:
//
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include "Building.h"

using namespace std;

int PrintMenu();
void FileReport(const int &iNumberOfBuildings, Building *buildings);
void FileStates(const int &iNumberOfBuildings, Building *buildings, states state);
void TurnOn(const int &iNumberOfBuildings, Building *buildings);
void TurnOff(const int &iNumberOfBuildings, Building *buildings);

const string CSV_FILE_NAME = "Report.csv";
const int MAX_BUILDINGS = 3;

int main()
{
	// get instnace of Randomizer used for generating random numbers
	Randomizer rRand = Randomizer::Instance();

	// generate a random number of buildings
	int iNumberOfBuildings = rRand.InRange(1, MAX_BUILDINGS);

	// allocate memory for the specific number of buildings
	Building *buildings = new Building[iNumberOfBuildings];

	// initialize the appropriate number of buildings
	for (int iCounter = 0; iCounter < iNumberOfBuildings; iCounter++)
		buildings[iCounter].Init(iCounter + 1, "Building_" + to_string(iCounter + 1));

	// report to the user the number of buidings initialized
	cout << "Program has initialized " << iNumberOfBuildings << " building(s).\n\n";
	system("pause");

	while (true)
	{

		switch (PrintMenu())
		{
		case 1: // Report on Everything
			FileReport(iNumberOfBuildings, buildings);
			break;
		case 2: // All APs
			FileStates(iNumberOfBuildings, buildings, NO_STATE);
			break;
		case 3: // On APs
			FileStates(iNumberOfBuildings, buildings, ON);
			break;
		case 4: // Off APs
			FileStates(iNumberOfBuildings, buildings, OFF);
			break;
		case 5: // display report
			system("cls");
			cout << CSV_FILE_NAME << " was opended for viewing...\n\n";
			system("Report.csv");
			break;
		case 6: // turn on
			TurnOn(iNumberOfBuildings, buildings);
			break;
		case 7: // turn off
			TurnOff(iNumberOfBuildings, buildings);
			break;
		case 8: // Quit
			return 0; // return to the OS
			break;
		default: // invalid selection
			cout << "\nInvalid selection...please choose something from the list\n\n";
			break;
		}

		system("pause");
	}

	return 0; // return to the OS

} // main

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Function:	PrintMenu
Pre:
Post:
*/
int PrintMenu()
{
	int selection;

	system("cls");
	cout << "1 - Generate Report on everything\n"
		<< "2 - Generate Report of all APs\n"
		<< "3 - Gernerate Report of all ON APs\n"
		<< "4 - Generate Report of all OFF APs\n\n"

		<< "5 - Display Report\n\n"

		<< "6 - Turn AP ON\n"
		<< "7 - Turn AP OFF\n\n"

		<< "8 - Quit\n\n"

		<< "Please enter your selection [1...8]: ";

	cin >> selection;

	return selection;

} // PrintMenu

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Function:	FileReport
Pre:
Post:
*/
void FileReport(const int &iNumberOfBuildings, Building *buildings)
{
	// variable pool
	ofstream fout;

	cout << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n";

	// open input & output files
	fout.open(CSV_FILE_NAME);
	cout << CSV_FILE_NAME << " was opened to write.\n\n";

	cout << "Creating Report..." << endl << endl;

	// Report on each building
	for (int iBuildCounter = 0; iBuildCounter < iNumberOfBuildings; iBuildCounter++)
	{
		// header for output of buildings
		fout << "#,Name,Floors\n";

		fout << iBuildCounter + 1 << ","
			<< buildings[iBuildCounter].GetName() << ","
			<< buildings[iBuildCounter].GetFloorCount() << endl;

		// header for output of floors
		fout << ",Floor #,Rooms\n";

		// Report on each floor
		for (int iFloorCounter = 0;
			iFloorCounter < buildings[iBuildCounter].GetFloorCount();
			iFloorCounter++)
		{
			fout << ","
				<< iFloorCounter + 1 << ","
				<< buildings[iBuildCounter].GetFloor(iFloorCounter).GetRoomCount() << endl;

			// header for output of rooms
			fout << ",,Room #,APs\n";

			// Report on each room
			for (int iRoomCounter = 0;
				iRoomCounter < buildings[iBuildCounter].GetFloor(iFloorCounter).GetRoomCount();
				iRoomCounter++)
			{
				fout << ","
					<< ","
					<< iRoomCounter + 1 << ","
					<< buildings[iBuildCounter].GetFloor(iFloorCounter).GetRoom(iRoomCounter).GetAPCount() << endl;

				// header for output of APs
				fout << ",,,AP,State,Turned On\n";

				// Report on each AP
				for (int iAPCounter = 0;
					iAPCounter < buildings[iBuildCounter].GetFloor(iFloorCounter).GetRoom(iRoomCounter).GetAPCount();
					iAPCounter++)
				{
					AccessPoint apTemp = buildings[iBuildCounter].GetFloor(iFloorCounter).GetRoom(iRoomCounter).GetAP(iAPCounter);

					fout << ","
						<< ","
						<< ","
						<< iAPCounter + 1 << ","
						<< apTemp.StatusToString() << ","
						<< apTemp.TurnedOnToString() << endl;
				} // AP for loop
			} // Room for loop
		} // Floor for loop
	} // Building for loop

	  // output files
	fout.close();
	cout << CSV_FILE_NAME << " was closed.\n\n";

} // FileReport

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Function:	FileReport
Pre:
Post:
*/
void FileStates(const int &iNumberOfBuildings, Building *buildings, states state)
{
	// variable pool
	ofstream fout;
	bool shoInReport;

	cout << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n";

	// open input & output files
	fout.open(CSV_FILE_NAME);
	cout << CSV_FILE_NAME << " was opened to write.\n\n";

	cout << "Creating Report..." << endl << endl;

	fout << "Buidling,Floor,Room,AP,Status,Turned On\n";

	// Iterate through all buildings
	for (int iBuildCounter = 0; iBuildCounter < iNumberOfBuildings; iBuildCounter++)
	{
		// Iterate through all floors
		for (int iFloorCounter = 0;
			iFloorCounter < buildings[iBuildCounter].GetFloorCount();
			iFloorCounter++)
		{
			// Iterate through all rooms
			for (int iRoomCounter = 0;
				iRoomCounter < buildings[iBuildCounter].GetFloor(iFloorCounter).GetRoomCount();
				iRoomCounter++)
			{
				// Iterate through all APs
				for (int iAPCounter = 0;
					iAPCounter < buildings[iBuildCounter].GetFloor(iFloorCounter).GetRoom(iRoomCounter).GetAPCount();
					iAPCounter++)
				{
					shoInReport = false;
					AccessPoint apTemp = buildings[iBuildCounter].GetFloor(iFloorCounter).GetRoom(iRoomCounter).GetAP(iAPCounter);

					switch (state)
					{
					case ON:
						if (apTemp.Status() == ON)
							shoInReport = true;
						break;
					case OFF:
						if (apTemp.Status() == OFF)
							shoInReport = true;
						break;
					default:
						shoInReport = true;
						break;
					}

					if (shoInReport)
						fout << iBuildCounter + 1 << ","
						<< iFloorCounter + 1 << ","
						<< iRoomCounter + 1 << ","
						<< iAPCounter + 1 << ","
						<< apTemp.StatusToString() << ","
						<< apTemp.TurnedOnToString() << endl;

				} // AP for loop
			} // Room for loop
		} // Floor for loop
	} // Building for loop

	// output files
	fout.close();
	cout << CSV_FILE_NAME << " was closed.\n\n";

} // FileCSV

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Function:	TurnOn
Pre:
Post:
*/
void TurnOn(const int &numberOfBuildings, Building *buildings)
{
	string input;
	string delimiter = ".";
	int building, floor, room, ap, month;
	int start = 0;
	int end = input.find(delimiter);

	system("cls");

	cout << "Turn Access Point On\n\n"

		<< "Valid input:\t building.floor.room.ap.month\n\n"
		<< "Enter access point: ";

	cin >> input;

	start = end + delimiter.length();
	end = input.find(delimiter, start);

	building = stoi(input.substr(start, end - start));
	start = end + delimiter.length();
	end = input.find(delimiter, start);

	floor = stoi(input.substr(start, end - start));
	start = end + delimiter.length();
	end = input.find(delimiter, start);

	room = stoi(input.substr(start, end - start));
	start = end + delimiter.length();
	end = input.find(delimiter, start);

	ap = stoi(input.substr(start, end - start));
	start = end + delimiter.length();
	end = input.find(delimiter, start);

	month = stoi(input.substr(start, end - start));

	cout << "You entered:\n"
		<< "\tBuilding: " << building << endl
		<< "\tFloor: " << floor << endl
		<< "\tRoom: " << room << endl
		<< "\tAP: " << ap << endl
		<< "\tMonth: ";

	switch (month)
	{
	case JANUARY:
		cout << "January";
		break;
	case FEBRUARY:
		cout << "February";
		break;
	case MARCH:
		cout << "March";
		break;
	case APRIL:
		cout << "April";
		break;
	case MAY:
		cout << "May";
		break;
	case JUNE:
		cout << "June";
		break;
	case JULY:
		cout << "July";
		break;
	case AUGUST:
		cout << "August";
		break;
	case SEPTEMBER:
		cout << "September";
		break;
	case OCTOBER:
		cout << "October";
		break;
	case NOBEMBER:
		cout << "November";
		break;
	case DECEMBER:
		cout << "December";
		break;
	default:
		cout << "[Not a valid month]";
		break;
	}

/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

	//your code goes heree


/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

} // TurnOn

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Function:	TurnOff
Pre:
Post:
*/
void TurnOff(const int &numberOfBuildings, Building *buildings)
{
	string input;
	string delimiter = ".";
	int building, floor, room, ap;
	int start = 0;
	int end = input.find(delimiter);

	system("cls");

	cout << "Turn Access Point Off\n\n"

		<< "Valid input:\t building.floor.room.ap\n\n"
		<< "Enter access point: ";

	cin >> input;

	start = end + delimiter.length();
	end = input.find(delimiter, start);

	building = stoi(input.substr(start, end - start));
	start = end + delimiter.length();
	end = input.find(delimiter, start);

	floor = stoi(input.substr(start, end - start));
	start = end + delimiter.length();
	end = input.find(delimiter, start);

	room = stoi(input.substr(start, end - start));
	start = end + delimiter.length();
	end = input.find(delimiter, start);

	ap = stoi(input.substr(start, end - start));

	cout << "You entered:\n"
		<< "\tBuilding: " << building << endl
		<< "\tFloor: " << floor << endl
		<< "\tRoom: " << room << endl
		<< "\tAP: " << ap << endl << endl;

/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

	//your code goes heree


/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

} // TurnOff