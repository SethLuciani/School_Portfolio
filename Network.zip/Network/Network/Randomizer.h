///////////////////////////////////////////////////////////////////////////////////////////////////////
// Specification & Implementation File: Randomizer.h
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/23/2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#include <random>
#include <time.h>

class Randomizer
{
public:
	////////////////////////////////////////  INSTANCE  ///////////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: Instance
	Pre:	None
	Post:
	*/
	static Randomizer& Instance()
	{
		static Randomizer INSTANCE;
		return INSTANCE;

	} // instance

	////////////////////////////////////////  OBSERVER FUNCITONS  /////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	InRange
	Pre:
	Post:
	*/
	int InRange(/* in */ int lowBound, /* in */ int highBound)
	{
		return lowBound + (rand() % (highBound - lowBound + 1));

	} // InRange

private:
	////////////////////////////////////////  CONSTRUCTOR  ////////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: Randomizer Constructor
	Pre:	None
	Post:
	*/
	Randomizer()
	{
		srand(time(NULL));

	} // Randomizer Constructor

}; // Randomizer class