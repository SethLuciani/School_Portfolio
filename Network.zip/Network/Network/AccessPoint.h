///////////////////////////////////////////////////////////////////////////////////////////////////////
// Specification File: AccessPoint.h
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/23/2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma once

#include <string>
#include "Randomizer.h"

enum states {/* 0 */ NO_STATE,
			 /* 1 */ ON,
			 /* 2 */ OFF
};

enum months {/* 0 */	NO_MONTH,	JANUARY,	FEBRUARY,	MARCH,		APRIL,
			 /* 5 */	MAY,		JUNE,		JULY,		AUGUST,		SEPTEMBER,
			 /* 10 */	OCTOBER,	 NOBEMBER,	DECEMBER
};

class AccessPoint
{
public:
	////////////////////////////////////////  CONSTRUCTORS  ///////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: AccessPoint Construcotr
	Pre:	None
	Post:	access point values are: iNumber = -999, status = OFF, and turnedOn = NONE
	*/
	AccessPoint();

	////////////////////////////////////////  DESTRUCTORS  ////////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: ~AccessPoint Destrucotr
	Pre:	None
	Post:	Memory has been cleaned up and returned to the OS
	*/
	~AccessPoint();

	////////////////////////////////////////  OPERATION FUNCITONS  ////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: AccessPoint Construcotr
	Pre:	values have been provided for iNum and month
	Post:	iNumber = iNum, turnedOn = month, and if month != NONE the status is set to ON
	Return: True if iNum >= 0 && iNum <=3 and valid month
	Flase if conditions are not met
	*/
	bool Init(/* in */ int iNum, /* in */ months month);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: TurnOn
	Pre:	valid month has been provided
	Post:	The access point gets turned on and the month has been set
	Return: False is returned if the access point was already on
	True is returned if the operation was successful
	*/
	bool TurnOn(/* in */ months month);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: TurnOff
	Pre:	class has been initialized
	Post:	The access point gets turned off and the month has been set to NONE
	Return: False is returned if the access point was already off
	True is returned if the operation was successful
	*/
	bool TurnOff();

	////////////////////////////////////////  OBSERVER FUNCITONS  /////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: Status
	Pre:	None
	Post:	status has been returned as a states object
	*/
	states Status();

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: SatusToString
	Pre:	None
	Post:	status has been returned as a string
	*/
	std::string StatusToString();

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: TurnedOn
	Pre:	None
	Post:	month has been returned as a months object
	*/
	months TurnedOn();

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: TurnedOnToString
	Pre:	None
	Post:	month has been returned as a string
	*/
	std::string TurnedOnToString();

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: GetAP_ID
	Pre:	None
	Post:	the AP_ID is returned
	*/
	int GetAP_ID();

private:

	// each access point has a unique number
	int iAP_ID;

	// Is the access point on or off:
	// 0 == NO_STATE, 1 == ON, 2 == OFF
	states status;

	// Month that the access point was turned on:
	// 0 == NO_MONTH == not on
	// 1 == JANUARY ... 12 == DECEMBER
	months turnedOn;

}; // AccessPoint