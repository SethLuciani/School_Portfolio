///////////////////////////////////////////////////////////////////////////////////////////////////////
// Specification File: Room.h
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/23/2015
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma once

#include "AccessPoint.h";

const int AP_MIN = 0;
const int AP_MAX = 3;

class Room
{
public:
	////////////////////////////////////////  CONSTRUCTORS  ///////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: Room
	Pre:	None
	Post:	iRoomNumber has been set to -999 and a random number of AccessPoint objects have
	been created
	*/
	Room();

	////////////////////////////////////////  DESTRUCTORS  ////////////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function: ~Room
	Pre:	None
	Post:	class destructor
	*/
	~Room();

	////////////////////////////////////////  OPERATION FUNCITONS  ////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	Init
	Pre:	iNum has been provided
	Post:	room number has been assigned
	*/
	void Init(/* in */ int iNum);

	////////////////////////////////////////  OBSERVER FUNCITONS  /////////////////////////////////////
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	GetAPCount
	Pre:	None
	Post:	total number of APs for this room instance is returned
	*/
	int GetAPCount();

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	GetAP
	Pre:	iNum has been supplied and is a valid AP number
	Post:	an AccessPoint object has been returned
	*/
	AccessPoint GetAP(/* in */ int iNum);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	TurnOff
	Pre:
	Post:
	*/
	bool TurnOff(/* in */ int iAP);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	Function:	TurnOn
	Pre:
	Post:
	*/
	bool TurnOn(/* in */ int iAP, /* in */ months month);

private:
	// get instnace of Randomizer used for generating random numbers
	Randomizer rRand = Randomizer::Instance();

	// each room has a unique number
	int iRoomNumber;

	// each instance of room has a number of APs
	int iNumberOfAPs;

	// used to represent the APs in each room instance
	AccessPoint *accessPoints;

}; // Room