/*###########################################################################################
File: Driver.cpp

Author: Seth Luciani
Course: CSCI 182 Introduction to Data Structures
Company: Principia College
Date: 4/28/2016

Description: This program utilizes a binary tree to store nodes. Each of these nodes
represents a company and includes a name, a ID number, Capital, and the amount the company
owes. The user will have 5 options in this program. The first option will be to add a new
company to the binary tree as a new node. The second option will be to pay a certain amount
to a company to lower their debt. The third option will be to accept a purchase order so 
the company's debt will go up. The fourth option will be to display the print out the
binary tree in order. The fifth option wil be to exit the program and have the updated
binary tree printed out to a new csv file. 

Resources: Google, TA's , Lee T. Kirill K. and Nick F.
############################################################################################*/

#include <iostream>
#include <fstream>
#include <string>
#include "Paper_BST.h"

using namespace std;

/*~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~~~~~~ DEFINES ~~~~*/
#define SEPERATOR "\n+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~\n"
#define FILE_NAME "paper.csv"
#define OUTPUT_FILE "paper_output.csv"

/*~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~~~~ PROTOTYPES ~~~~~~~*/
int Menu();
void LoadDB(Paper_BST &);
void AddRecord(Paper_BST &);
void IssuePayment(Paper_BST &);
void AcceptPurchase(Paper_BST &);
void PrintSummary(Paper_BST &);
void PrintHeader();
void Quit(Paper_BST &);

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M A I N ** M A I N ** M A I N ** M A I N ** M A I N ** M A I N ** M A I N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
int main()
{
	Paper_BST bt;

	LoadDB(bt);

	while (true)
	{
		// display menu and then switch on the user selection
		switch (Menu())
		{
		case 0: goto quit; // quit program...jump down to quit label
		case 1: AddRecord(bt); break;
		case 2: IssuePayment(bt); break;
		case 3: AcceptPurchase(bt); break;
		case 4: PrintSummary(bt); break;
		default: cout << "Invalid Selection...try again\n\n"; break;
		} // switch
		  // wait for user input and then clear the screen for the next program itteration

		system("pause");

		system("cls");
	} // while loop

quit: // quit program label
	Quit(bt);
	return 0; // return with the status of 0 == Success
} // main

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Function: Menu

Pre: The program has been started

Post: The menu has been outputted to the user
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
int Menu()
{
	// variable pool
	int selection;
	cout << "Binary Tree Program\n\n"
		<< "1\tAdd Record\n"
		<< "2\tIssue a Payment\n"
		<< "3\tAccept a Purchase Order\n"
		<< "4\tPrint Summary Report\n\n"
		<< "0\tQuit\n\n"
		<< "Selection: ";
	// get user selected menu item
	cin >> selection;
	// check to see if we have valid input
	if (cin.good())
	{
		// clean up the input buffer...needed to handle invalid input
		cin.ignore(INT_MAX, '\n');
		return selection;
	}
	else
	{
		// clear cin errors
		cin.clear();
		// clean up the input buffer...needed to handle invalid input
		cin.ignore(INT_MAX, '\n');
		return INT_MAX;
	}
} // Menu

 /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Function: LoadDB

 Pre: There must be a file declared

 Post: The values from the csv file have been loaded and separated into 9 different nodes
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

void LoadDB(Paper_BST & bt)
{
	// Variable Pool
	fstream fin;
	company_type compTemp;
	string input;

	// opening the file
	fin.open(FILE_NAME);
	cout << FILE_NAME << " was opened to read.\n";

	// A while loop that is retrieving all of the values from the file
	while (!fin.eof())
	{
		getline(fin, input, ',');
		compTemp.id = stoi(input);

		getline(fin, input, ',');
		compTemp.name = input;

		getline(fin, input, ',');
		compTemp.cap = stod(input);

		getline(fin, input);
		compTemp.due = stod(input);

		// Inserting the values into the binary tree
		bt.Insert(compTemp);

	}

	// closing the file
	fin.close();
	cout << FILE_NAME << " was closed\n";

	// balancing the binary tree
	bt.Balance();

	// counting the number of nodes in the binary tree and displaying the height
	cout << bt.CountNode() << " companies have been created.\n";
	cout << "Height: " << bt.Height() << endl;
	cout << SEPERATOR;

	system("pause");
	system("cls");

} // LoadDB

 /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Function: AddRecord

 Pre: There are companies loaded up in the binary tree

 Post: A new company has been added to the binary tree
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

void AddRecord(Paper_BST & bt)
{
	// variable pool
	company_type CompTemp;
	string input;

	system("cls");

	// User Input
	cout << "Add Record" << endl << endl;
	cout << "Enter ID number of company you would like to add: ";
	cin >> input;
	cout << endl;

	// Changing the input from string to an int
	CompTemp.id = stoi(input);

	cout << "Enter Company name: ";
	cin >> input;
	CompTemp.name = input;
	cout << endl;

	// Inserting the new company into the binary tree
	bt.Insert(CompTemp);

} // AddRecord

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Function: IssuePayment

Pre: The companies have been stored in the binary tree

Post: The amount inputted by the user will be subtracted from the amount due
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

void IssuePayment(Paper_BST & bt)
{
	// variable pool
	company_type CompTemp;
	company_type *CompTempP;
	int input;
	double temp;

	system("cls");
	cout << "Issue a payment\n\n";

	// user interaction
	cout << "Enter the company ID that you would like to issue a payment to: ";
	cin >> input;

	CompTemp.id = input;

	cout << "\nEnter the amount of the payment: ";
	cin >> temp;
	cout << endl;

	// Initializing the pointer
	CompTempP = bt.GetNode(CompTemp);

	// how to handle if they try to pay off too much of the debt
	// no negatives!
	if (temp > CompTempP->due)
	{
		cout << "Invalid Input... Program closing\n";
		system("pause");
		exit(0);
	}
	else
	{
		// subtracting the amount from the amount due
		CompTempP = bt.GetNode(CompTemp);
		CompTempP->due -= temp;
	}

} // IssuePayment

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Function: AcceptPurchase

Pre: The user has chosen accept purchase

Post: The company's updated price will be displayed when printed 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

void AcceptPurchase(Paper_BST & bt)
{
	// variable pool
	company_type CompTemp;
	company_type *CompTempP;
	int input;
	double temp;

	system("cls");
	cout << "Accept a Purchase Order\n\n";

	// user interaction
	cout << "Enter the company ID that you would like to accept a purchase order for: ";
	cin >> input;

	CompTemp.id = input;

	cout << "\nEnter the amount of the purchase order: ";
	cin >> temp;
	cout << endl;

	// Initializing the pointer
	CompTempP = bt.GetNode(CompTemp);

	// how to handle if they try to pay off too much of the debt
	// no negatives!
	if (temp < CompTempP->due)
	{
		cout << "Invalid Input... Program closing\n";
		system("pause");
		exit(0);
	}
	else
	{
		// subtracting the amount from the amount due
		CompTempP = bt.GetNode(CompTemp);
		CompTempP->due += temp;
	}
} // AcceptPurchase

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Function: PrintSummary

Pre: The user selects Print Summary

Post: Printed to the console will be all of the companies with their id #'s, capital, and 
amount due
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

void PrintSummary(Paper_BST & bt)
{
	// printing out the binary tree in order
	system("cls");
	PrintHeader();
	bt.InOrder(cout);
} // PrintSummary

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Function: PrintHeader

Pre: The program has been started

Post: A header for printing out has been created 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

void PrintHeader()
{
	// Creating a all purpose header for printing out
	cout.setf(std::ios::left);
	cout << std::setw(10) << "ID"
		 << std::setw(40) << "Company"
		 << std::setw(21) << "CAP"
		 << std::setw(20) << "DUE" << endl;
} // PrintHeader

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Function: Quit

Pre: The user has selected quit

Post: The program closes and the new binary tree is saved to a new csv file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

void Quit(Paper_BST & bt)
{
	company_type CompTemp;
	company_type* CompTemp2;

	ofstream fout;
	fout.open(OUTPUT_FILE);

	for (int i = 1000; i < 10000; i++)
	{
		CompTemp2 = bt.GetNode(CompTemp);
	}

	fout.close();
	cout << OUTPUT_FILE;

} // Quit

/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E O F ** E O F ** E O F ** E O F ** E O F ** E O F ** E O F
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/