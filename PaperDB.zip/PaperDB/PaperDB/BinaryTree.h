/*###########################################################################################
File: BinaryTree.h
Author: John Broere
Course: CSCI 182 Introduction to Data Structures
Company: Principia College
Date: 5/6/2015
Description:
############################################################################################*/
#pragma once
#include <iostream>

// user defined structure for nodes of the tree
template<class ItemType>
struct node
{
	// node variables
	ItemType item;
	node<ItemType> *left;
	node<ItemType> *right;
	// default constructor
	node() { left = right = nullptr; }
	// constructor
	node(ItemType i, node<ItemType> *l = nullptr, node<ItemType> *r = nullptr)
	{
		item = i;
		left = l;
		right = r;
	}
}; // node struct
template<class ItemType>
class BinaryTree
{
public:

/*########################################################################################
Pre:
Post:
########################################################################################*/

BinaryTree() { root = nullptr; } // BinaryTree Default Constructor

/*########################################################################################
Pre:
Post:
########################################################################################*/

BinaryTree(const BinaryTree<ItemType> &bt); // BinaryTree Copy Constructor

/*########################################################################################
Pre:
Post:
########################################################################################*/

~BinaryTree();

////////////////////////////////// OPERATION FUNCITONS /////////////////////////////////

/*########################################################################################
Pre:
Post:
########################################################################################*/

BinaryTree<ItemType>& operator= (const BinaryTree<ItemType> &bt); // operator=

/*########################################################################################
Pre:
Post:
########################################################################################*/

bool operator== (BinaryTree<ItemType> ); // operator==

////////////////////////////////// OBSERVER FUNCITONS //////////////////////////////////

/*########################################################################################
Pre:
Post:
########################################################################################*/

bool IsEmpty() { return root == nullptr; } // IsEmpty

/*########################################################################################
Pre:
Post:
########################################################################################*/

int Height() { return Height(root); } // Height

/*########################################################################################
Pre:
Post:
########################################################################################*/

int CountNode() { return CountNode(root); } // CountNode

/*########################################################################################
Pre:
Post:
########################################################################################*/

void PreOrder(std::ostream &os) const { PreOrder(root, os); } // PreOrder

/*########################################################################################
Pre:
Post:
########################################################################################*/

void InOrder(std::ostream &os) const { InOrder(root, os); } // InOrder

/*########################################################################################
Pre:
Post:
########################################################################################*/

void PostOrder(std::ostream &os) const { PostOrder(root, os); } // PostOrder

/*########################################################################################
Pre:
Post:
########################################################################################*/

ItemType* Largest(bool(*lessthan) (ItemType, ItemType)); // Largest
protected:
// root of the BinaryTree
node<ItemType> *root;

/*########################################################################################
Pre:
Post:
########################################################################################*/

bool TreeEqual(node<ItemType>*, node<ItemType>*); // TreeEqual

/*########################################################################################
Pre:
Post:
########################################################################################*/

node<ItemType>* CopyTree(node<ItemType> *rt) const; // CopyTree

/*########################################################################################
Pre:
Post:
########################################################################################*/

void DestroyTree(node<ItemType> *rt); // DestroyTree

/*########################################################################################
Pre:
Post:
########################################################################################*/

int Height(node<ItemType> *rt); // Height

/*########################################################################################
Pre:
Post:
########################################################################################*/

int CountNode(node<ItemType> *rt); // CountNode

/*########################################################################################
Pre:
Post:
########################################################################################*/

void PreOrder(node<ItemType>* rt, std::ostream &) const; // PreOrder

/*########################################################################################
Pre:
Post:
########################################################################################*/

void InOrder(node<ItemType>* rt, std::ostream &) const; // InOrder

/*########################################################################################
Pre:
Post:
########################################################################################*/

void PostOrder(node<ItemType>* rt, std::ostream &) const; // PostOrder

/*########################################################################################
Pre:
Post:
########################################################################################*/

node<ItemType>* Largest(node<ItemType>* rt,

bool(*lessthan) (ItemType, ItemType)); // Largest
}; // BinaryTree class

/*********************************************************************************************
COPY CONSTRUCTOR ** COPY CONSTRUCTOR ** COPY CONSTRUCTOR ** COPY CONSTRUCTOR
*********************************************************************************************/
template<class ItemType>

BinaryTree<ItemType>::BinaryTree(const BinaryTree<ItemType> &bt)
{
	root = CopyTree(bt.root);
} // BinaryTree

/*********************************************************************************************
DESTRUCTOR ** DESTRUCTOR ** DESTRUCTOR ** DESTRUCTOR ** DESTRUCTOR ** DESTRUCTOR
*********************************************************************************************/
template<class ItemType>

BinaryTree<ItemType>::~BinaryTree()
{
	DestroyTree(root);
	root = nullptr;
} // ~BinaryTree

/*********************************************************************************************
OPERATOR OVERLOADING ** OPERATOR OVERLOADING ** OPERATOR OVERLOADING
*********************************************************************************************/
template<class ItemType>

BinaryTree<ItemType>& BinaryTree<ItemType>::operator= (const BinaryTree<ItemType> &bt)
{
	DestroyTree(root);
	root = CopyTree(bt.root);
	return *this;
} // operator=

/********************************************************************************************/
template<class ItemType>

bool BinaryTree<ItemType>::operator==(BinaryTree<ItemType> bt)
{
	return TreeEqual(root, bt.root);
} // operator==

/********************************************************************************************/
template<class ItemType>

ItemType* BinaryTree<ItemType>::Largest(bool(*lessthan) (ItemType, ItemType))
{
	node<ItemType> *lg = Largest(root, (*lessthan));
	if (lg)
		return &(lg->item);
	else
		return nullptr;
}// Largest

/*********************************************************************************************
MEMBER FUNCITONS ** MEMBER FUNCITONS ** MEMBER FUNCITONS ** MEMBER FUNCITONS
*********************************************************************************************/
template<class ItemType>

bool BinaryTree<ItemType>::TreeEqual(node<ItemType> *rt1, node<ItemType> *rt2)
{
	if (rt1 == nullptr && rt2 == nullptr) // both are empty
		return true;
	else if (rt1 == nullptr || rt2 == nullptr) // one is empty
		return false;
	else if (rt1->item == rt2->item) // roots have same data
		return TreeEqual(rt1->left, rt2->left) &&
		TreeEqual(rt1->right, rt2->right); // check leaves
	else // roots have different data
		return false;
} // TreeEqual
/********************************************************************************************/
template<class ItemType>

node<ItemType>* BinaryTree<ItemType>::CopyTree(node<ItemType> *rt) const
{
	node<ItemType> *newRoot = nullptr;
	if (rt != nullptr) // recursively copy all data until we reach the end of the tree
		newRoot = new node<ItemType>(rt->item, CopyTree(rt->left), CopyTree(rt->right));
	return newRoot;
} // CopyTree

/********************************************************************************************/
template<class ItemType>

void BinaryTree<ItemType>::DestroyTree(node<ItemType> *rt)
{
	if (rt != nullptr)
	{
		DestroyTree(rt->left);
		DestroyTree(rt->right);
		delete rt;
	}
} // DestroyTree

/********************************************************************************************/
template<class ItemType>

int BinaryTree<ItemType>::Height(node<ItemType> *rt)
{
	int l, r;
	if (rt == nullptr) // base case...tree is empty
		return 0;
	else
		return ((l = Height(rt->left) + 1) > (r = Height(rt->right) + 1)) ? l : r;
} // Height

/********************************************************************************************/
template<class ItemType>

int BinaryTree<ItemType>::CountNode(node<ItemType> *rt)
{
	if (rt == nullptr)
		return 0;
	else
		return CountNode(rt->left) + CountNode(rt->right) + 1;
} // CountNode

/********************************************************************************************/
template<class ItemType>

void BinaryTree<ItemType>::PreOrder(node<ItemType>* rt, std::ostream &os) const
{
	if (rt != nullptr)
	{
		// output current node
		os << rt->item << endl;
		// recursively check left nodes
		if (rt->left != nullptr)
			PreOrder(rt->left, os);
		// recursively check right nodes
		if (rt->right != nullptr)
			PreOrder(rt->right, os);
	}
} // PreOrder

/********************************************************************************************/
template<class ItemType>

void BinaryTree<ItemType>::InOrder(node<ItemType>* rt, std::ostream &os) const
{
	if (rt != nullptr)
	{
		InOrder(rt->left, os);
		os << rt->item << endl;
		InOrder(rt->right, os);
	}
} // InOrder
/********************************************************************************************/
template<class ItemType>

void BinaryTree<ItemType>::PostOrder(node<ItemType>* rt, std::ostream &os) const
{
	if (rt != nullptr)
	{
		PostOrder(rt->left, os);
		PostOrder(rt->right, os);
		os << rt->item << endl;
	}
} // PostOrder

/********************************************************************************************/
template<class ItemType>
node<ItemType>* BinaryTree<ItemType>::Largest(node<ItemType>* rt,
	bool(*lessthan) (ItemType, ItemType))
{
	node<ItemType> *lg = rt, *llg, *rlg;
	if (rt == nullptr)
		return nullptr;
	// check left
	if ((llg = Largest(rt->left, lessthan)) != nullptr && lessthan(lg->item, llg->item))
		lg = llg;
	// check right
	if ((rlg = Largest(rt->right, lessthan)) != nullptr && lessthan(lg->item, rlg->item))
		lg = rlg;
	return lg;
}// Largest

 /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 E O F ** E O F ** E O F ** E O F ** E O F ** E O F ** E O F
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
