/*###########################################################################################
File: Student_BST.cpp
Author: John Broere
Course: CSCI 182 Introduction to Data Structures
Company: Principia College
Date: 5/6/2016
Description:
############################################################################################*/

#include "Paper_BST.h"
#include "BinaryTree.h"

/*##########################################################################################*/

std::ostream& operator<< (std::ostream& os, company_type s)
{
	os.setf(std::ios::left);
	os << std::fixed << std::showpoint
		<< std::setw(10) << s.id
		<< std::setw(40) << s.name
		<< std::setw(21) << s.cap
		<< std::setw(20) << std::setprecision(1) << s.due;
	return os;
} // operator<<

//std::ostream& operator>> (std::ostream& os, company_type s)
//{
//	os.setf(std::ios::left);
//	os << std::fixed << std::showpoint
//		<< "," << s.id
//		<< "," << s.name
//		<< "," << s.cap
//		<< "," << std::setprecision(1) << s.due;
//	return os;
//} // operator<<
  /*##########################################################################################*/
void Paper_BST::Insert(company_type &s)
{
	Insert(root, s);
} // Insert
  /*##########################################################################################*/
company_type* Paper_BST::GetNode(company_type &s)
{
	node<company_type> *tmp = root, *prev = nullptr;
	while (tmp != nullptr && !(tmp->item == s))
	{
		prev = tmp;
		if (tmp->item < s)
			tmp = tmp->right;
		else
			tmp = tmp->left;
	}
	if (tmp != nullptr && tmp->item == s)
		return &(tmp->item);
	else
		return nullptr;
} // GetNode
  /*##########################################################################################*/
void Paper_BST::Delete(company_type &s)
{
	node<company_type> *tmp = root, *prev = nullptr;
	while (tmp != nullptr && !(tmp->item == s))
	{
		prev = tmp;
		if (tmp->item < s)
			tmp = tmp->right;
		else
			tmp = tmp->left;
	}
	if (tmp != nullptr && tmp->item == s)
		if (tmp == root)
			Delete(root);
		else if (prev->left == tmp)
			Delete(prev->left);
		else
			Delete(prev->right);
	else
		std::cout << "not in tree.\n";
} // Delete
  /*##########################################################################################*/
void Paper_BST::MakeBST(company_type data[], int F, int L)
{
	if (root)
		DestroyTree(root);
	root = MakeBSTP(data, F, L);
} // Make_BST
  /*##########################################################################################*/
void Paper_BST::Balance()
{
	company_type *data;
	int N = CountNode(root);
	data = new company_type[N];
	DumpTree(root, data, 0, N - 1);
	DestroyTree(root);
	root = MakeBSTP(data, 0, N - 1);
	delete[] data;
} // Balance
  /*##########################################################################################*/
void Paper_BST::Insert(node<company_type>* &rt, company_type &s)
{
	if (rt == nullptr)
		rt = new node<company_type>(s);
	else if (s < rt->item)
		Insert(rt->left, s);
	else
		Insert(rt->right, s);
} // Insert
  /*##########################################################################################*/
void Paper_BST::Delete(node<company_type>* &nd)
{
	node<company_type> *prev, *tmp = nd;
	if (nd->right == nullptr)
		nd = nd->left;
	else if (nd->left == nullptr)
		nd = nd->right;
	else
	{
		prev = nd;
		tmp = nd->left;
		while (tmp->right != nullptr)
		{
			prev = tmp;
			tmp = tmp->right;
		}
		nd->item = tmp->item;
		if (prev == nd)
			prev->left = tmp->left;
		else
			prev->right = tmp->left;
	}
	delete tmp;
} // Delete
  /*##########################################################################################*/
node<company_type>* Paper_BST::MakeBSTP(company_type data[], int F, int L)
{
	node<company_type> *rt = nullptr;
	if (F <= L)
	{
		int M = (F + L) / 2;
		rt = new node<company_type>(data[M], MakeBSTP(data, F, M - 1), MakeBSTP(data, M + 1, L));
	}
	return rt;
} // Make_BSTP
  /*##########################################################################################*/
void Paper_BST::DumpTree(node<company_type> *rt, company_type *data, int F, int L)
{
	if (rt != nullptr)
	{
		int leftCount = CountNode(rt->left);
		data[leftCount + F] = rt->item;
		DumpTree(rt->right, data, leftCount + F + 1, L);
		DumpTree(rt->left, data, F, F + leftCount - 1);
	}
} // DumpTree
  /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  E O F ** E O F ** E O F ** E O F ** E O F ** E O F ** E O F
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/