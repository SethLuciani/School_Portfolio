#include <iostream>





#include <fstream>














#include <string>



#include <array>


#include <iomanip>
																																																	using namespace std;const string sINPUT_FILE_NAME = 

















"Input.txt";














const int iALPHA_MAX = 26;void DictionaryInit(string dictionary[]);












void DictionaryPrint(const string dictionary[]);string ParsePhrase(const string dictionary[], string phrase);

int main()
{
	string CAODictionary[iALPHA_MAX];string sInputPhrase;DictionaryInit(CAODictionary);DictionaryPrint(CAODictionary);

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
system("pause");system("cls");DictionaryPrint(CAODictionary);printf("Enter a phrase to convert to ICAO (only enter valid chars from above and spaces).\n\nInput: ");
	getline(cin, sInputPhrase);printf("\nTranslation:\n%s\n\n", ParsePhrase(CAODictionary, sInputPhrase).c_str());system("pause");
							
																			return 0;}

void DictionaryInit(string dictionary[])
{
	ifstream fin;
	fin.open(sINPUT_FILE_NAME);
	printf("%s opened to read.\n", sINPUT_FILE_NAME.c_str());
	printf("\tInitializing Array...\n");
	for (int x = 0; x < iALPHA_MAX; x++)
		fin >> dictionary[x];
	fin.close();
	printf("%s has been closed.\n\n", sINPUT_FILE_NAME.c_str());
}


void DictionaryPrint(const string dictionary[])
{

















	cout << "ICAO Dictionary:\n";cout.setf(ios::left);










	for (int x = 0; x < iALPHA_MAX; x++){
																						cout << setw(2) << char(x + 65) << ": " << setw(10) << dictionary[x++];
		cout << setw(2) << char(x + 65) << ": " << setw(10) << dictionary[x] << endl;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}cout << endl;																																	}

string ParsePhrase(const string dictionary[], string phrase)
{string parsedPhrase = "\t";char previousChar = ' ';
for (int i = 0; i < phrase.length(); i++)
{if (phrase[i] != ' '){if (i > 0 & previousChar != ' ')parsedPhrase += " ";
parsedPhrase += dictionary[char(previousChar = toupper(phrase[i]) - 65)];}
else{previousChar = ' ';parsedPhrase += "\n\t";}}return parsedPhrase;}