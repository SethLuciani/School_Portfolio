/*###########################################################################################
File: PlanetaryWeight.cpp

Author:		Seth Luciani
Company:	Principia College
Course:		CSCI 182 - Introduction to Data Structures
Professor:	John Broere
Date:		2/3/16

Description:	In this program we are entering planets into an enumeration type and using them to output the weight of the 
user on different planets within our solar system.


Sources: The Textbook, TA's, and the Internet.
###########################################################################################*/

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

// Declaring the enum Planets
enum Planets { Mercury, Venus, Earth, Moon, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto, InvalidPlanet};

double getWeight(Planets planet);			// Calling in Function
Planets stringToEnum(string planetName);	// Calling in Function

int main()
{
	// Variable Pool
	Planets curPlanet;
	double weight;
	string planet;
	string input;


	cout << "Enter your weight on Earth in Pounds (eg. 175.9): ";			// Output
	cin >> weight;				// This problem also needs to be solved. Everything works if you enter it correctly.
	if (cin.fail()) {									// If the weight is entered incorrectly output exit statement
		cout << "Invalid Input...not a number" << endl;
		system("pause");
		return -1;
	}
	// If the weight entered was valid then continue
	cout << "Select a planet from this list to see what you would weigh on the surface. " << endl;
	cout << endl;

	cout << setw(10) << " " << left << setw(15) << "Mercury" << setw(15) << "Venus" << endl;				// Formatting for the output
	cout << setw(10) << " " << left << setw(15) << "Earth" << setw(15) << "Moon" << endl;
	cout << setw(10) << " " << left << setw(15) << "Mars" << setw(15) << "Jupiter" << endl;
	cout << setw(10) << " " << left << setw(15) << "Saturn" << setw(15) << "Uranus" << endl;
	cout << setw(10) << " " << left << setw(15) << "Neptune" << setw(15) << "Pluto" << endl;

	cout << endl;
	cout << "Be sure to enter the planet name as shown above. " << endl;
	cout << "Input: ";			// Input for Planet Name
	cin >> planet;
	cout << endl;
	curPlanet = stringToEnum(planet); // Checking to make sure the planet entered was one of the specified planets
	
	if (curPlanet != InvalidPlanet) // Checking to see if its a valid planet
	{
		cout << "Planet Name: " << planet << endl;
		cout << "Weight Factor: " << getWeight(stringToEnum(planet)) << endl;
		cout << "You would weigh: " << getWeight(stringToEnum(planet)) * weight << " lbs." << endl;
		cout << endl;
	}
	else {
		// Invalid planet entered
		cout << "Error...you did not enter a planet name." << endl;
		cout << endl;
		system("pause");
		return -1;
	}
	

		system("pause");
	return 0;
}// Main

Planets stringToEnum(string planetName) // If else's used to check if the name entered for planet is equal to a member of the enum
{
	if (planetName == "Mercury") {
		return Mercury;
	}
	else if (planetName == "Venus") {
		return Venus;
	}
	else if (planetName == "Earth") {
		return Earth;
	}
	else if (planetName == "Moon") {
		return Moon;
	}
	else if (planetName == "Mars") {
		return Mars;
	}
	else if (planetName == "Jupiter") {
		return Jupiter;
	}
	else if (planetName == "Saturn") {
		return Saturn;
	}
	else if (planetName == "Uranus") {
		return Uranus;
	}
	else if (planetName == "Neptune") {
		return Neptune;
	}
	else if (planetName == "Pluto") {
		return Pluto;
	}
	else
		return InvalidPlanet;				// Used if they did not enter a valid planet name

	
}

double getWeight(Planets planet) { // A function that associates the planet from the enum with the gravitational pull from that planet
	switch (planet)
	{
	case Mercury:
		return 0.4155;
	case Venus:
		return 0.8975;
	case Earth:
		return 1.0;
	case Moon:
		return 0.166;
	case Mars:
		return 0.3507;
	case Jupiter:
		return 2.5374;
	case Saturn:
		return 1.0677;
	case Uranus:
		return 0.8947;
	case Neptune:
		return 1.1794;
	case Pluto:
		return 0.0899;
	}
}


