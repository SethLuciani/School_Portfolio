/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Main Program File: GeologicTimes.cpp
//
// Author:	John Broere
// Course:	CSCI 182 - Introduction to Data Structures
// Company: Principia College
// Date:	02/18/2015
//
// Description: This program is in response to Chapter 12 Programming Problem #4 and
//					Warm-Up Exercises 7-12.
//	
//	The purpose of this program is to implement class specification and implementation
//		files for geologic periods.  The main program declares an instance of the class
//		using the default and overrided constructors.  Using a for loop all the periods are
//		displayed to the console from earliest to most recent for each instance.
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <iostream>	// cin and cout
#include <string>	// strings
#include <iomanip>	// setw
#include <locale>	// formatting numbers with commas
#include "Periods.h"	// Includes Periods.h header file

using namespace std;

int main()
{
	// variable pool
	Periods geoTimes_Default;
	Periods geoTimes_Overloaded(Jurassic);

	// setup for console output formatting
	cout.imbue(locale(""));
	cout.setf(ios::left);

	cout << "Geologic times ordered from earliest to most recent.\n\n";

	// header for list to follow
	cout << setw(18) << "Period Name" << "Starting Date (millions of years)" << endl;
	cout << setw(18) << "___________" << "_________________________________" << endl;

	// iterate through periods starting with the current period for the default constructor instance
	for (int iCounter = geoTimes_Default.ToInt(); iCounter < TOTAL_PERIODS; iCounter++)
	{
		cout << setw(18) << geoTimes_Default.PeriodName() 
			 << geoTimes_Default.PeriodStart() << endl;
		
		geoTimes_Default.PeriodIncrement();
	}

	// line break between two tables
	cout << endl;

	cout << "Starting Period: " << geoTimes_Overloaded.PeriodName() << endl << endl;

	// header for list to follow
	cout << setw(18) << "Period Name" << "Starting Date (millions of years)" << endl;
	cout << setw(18) << "___________" << "_________________________________" << endl;

	// iterate through periods starting with the current period for the overloaded constructor instance
	for (int iCounter = geoTimes_Overloaded.ToInt(); iCounter < TOTAL_PERIODS; iCounter++)
	{
		cout << setw(18) << geoTimes_Overloaded.PeriodName() << geoTimes_Overloaded.PeriodStart() << endl;
		geoTimes_Overloaded.PeriodIncrement();
	}

	// spacing for end of program
	cout << endl;

	system("pause"); // system call to wait for user input

	return 0;

} // main