#include "Periods.h"

Periods::Periods()
{
} // Default Constructor

Periods::Periods(enum periods)
{
}	// Overloaded Constructor

int Periods::ToInt(enum periods)	// turns enum into its respective number using a switch
{
	
}

string Periods::PeriodName()
{
	string nameArray[12];

	nameArray[0] = "Precambrian";
	nameArray[1] = "Cambrian";
	nameArray[2] = "Ordovician";
	nameArray[3] = "Silurian";
	nameArray[4] = "Devonian";
	nameArray[5] = "Carboniferous";
	nameArray[6] = "Permian";
	nameArray[7] = "Triassic";
	nameArray[8] = "Jurassic";
	nameArray[9] = "Cretaceous";
	nameArray[10] = "Paleogene";
	nameArray[11] = "Neogene";
}

int Periods::PeriodStart(int curPeriod)
{
	int startArray[12];
		startArray[0] = 4500;
		startArray[1] = 570;
		startArray[2] = 500;
		startArray[3] = 435;
		startArray[4] = 395;
		startArray[5] = 345;
		startArray[6] = 280;
		startArray[7] = 225;
		startArray[8] = 192;
		startArray[9] = 136;
		startArray[10] = 65;
		startArray[11] = 23;

		return startArray[curPeriod];

}

void Periods::PeriodIncrement(int curPeriod)
{
	curPeriod = curPeriod++;
}


Periods::~Periods()
{
} // Destructor