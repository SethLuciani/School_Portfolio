#pragma once

#include <string>

using namespace std;

/*
type defining the different available periods from oldest to
newest...TOTAL_PERIODS is used to track the total periods and appears lasts.
*/
enum periods {	/*0*/  Precambrian, Cambrian, Ordovician, Silurian, Devonian,
				/*5*/  Carboniferous, Permian, Triassic, Jurassic, Cretaceous,
				/*10*/ Paleogene, Neogene, TOTAL_PERIODS
};

class Periods
{
public:
	Periods();
	Periods(enum periods);
	~Periods();
	~Periods();

	int ToInt(enum periods);
	string PeriodName();
	int PeriodStart(int curPeriod);
	void PeriodIncrement(int curPeriod);

private:
	periods curPeriod;	// class variable for keeping track of the current period

}; // Periods Class